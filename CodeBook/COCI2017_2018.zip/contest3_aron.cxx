#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;
int main() {
    std::ios::sync_with_stdio(false);
    cin.tie(0);
    
    int ans = 1;
    string last = "42";
    int n;
    cin >> n;
    for(int i = 0; i<n; i++){
        string s;
        cin >> s;
        if(s!=last){
            ans++;
        }
        last = s;
    }
    cout << ans << endl;
    return 0;
}