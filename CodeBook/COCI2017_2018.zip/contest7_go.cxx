#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define f(i, x, n) for(int i = x; i < (int)(n); ++i)

struct M{
	int h, pr, t;
	M(){}
	void sc() { scanf("%d%d%d", &h, &pr, &t); }
}p[100];

inline void up(int &x, int y) { x = max(x, y); }

int dp[2001][100][100][2], inf = 1e9;

int main(){
	int n, st, m;
	scanf("%d%d%d", &n, &st, &m);
	f(i, 0, m)p[i].sc();
	f(i, 0, 2001)f(j, 0, m)f(k, 0, m)dp[i][j][k][0] = dp[i][j][k][1] = -inf;
	f(i, 0, m)dp[abs(st - p[i].h)][i][i][0] = abs(st - p[i].h) < p[i].t ? p[i].pr : 0;
	f(i, 0, 2000)f(sz, 1, m + 1)f(l, 0, m - sz + 1)f(k, 0, 2){
		int r = l + sz - 1;
		int &d = dp[i][l][r][k];
		if (d <= -inf)continue;
		int ps = k ? p[r].h : p[l].h;
		f(w, 0, 2){
			if (w == 0 && l == 0)continue;
			if (w == 1 && r + 1 == m)continue;
			int nl = w ? l : l - 1;
			int nr = w ? r + 1 : r;
			int cr = w ? r + 1 : l - 1;
			int nps = p[cr].h;
			int dis = abs(nps - ps);
			if (i + dis > 2000)continue;
			up(dp[i + dis][nl][nr][w], d + (i + dis < p[cr].t ? p[cr].pr : 0));
		}
	}
	int an = 0;
	f(i, 0, 2001)up(an, max(dp[i][0][m - 1][0], dp[i][0][m - 1][1]));
	printf("%d\n", an);
}