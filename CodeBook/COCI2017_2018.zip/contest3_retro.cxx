#include <iostream>

using namespace std;

int N, M;
string d[2][300][310];
string s[300];
string meg, h;
bool jo[2][300][300];

string jobb(string x, string y){
    if(x.length()<y.length()) return (y);
    if(y.length()<x.length()) return (x);
    if(x<y) return (x);
    return (y);
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin >> N >> M;
    for(int i=0; i<N; i++){
        cin >> s[i];
    }
    for(int i=0; i<M; i++){
        if(s[N-1][i]=='M'){
            jo[(N-1)%2][i][0] = true;
            d[(N-1)%2][i][0] = "";
        }
    }
    for(int i=N-2; i>=0; i--){
        for(int j=0; j<M; j++){
            for(int k=0; k<N/2+10; k++){
                jo[i%2][j][k] = false;
                d[i%2][j][k] = "";
            }
        }
        for(int j=0; j<M; j++){
            if(s[i][j]!='*'){
                for(int k=0; k<N/2+10; k++){
                    if(s[i][j]=='.'){
                        if(j!=0 && jo[(i+1)%2][j-1][k]){
                            d[i%2][j][k] = jobb(d[i%2][j][k],d[(i+1)%2][j-1][k]);
                            jo[i%2][j][k] = true;
                        }
                        if(j!=M-1 && jo[(i+1)%2][j+1][k]){
                            d[i%2][j][k] = jobb(d[i%2][j][k],d[(i+1)%2][j+1][k]);
                            jo[i%2][j][k] = true;
                        }
                        if(jo[(i+1)%2][j][k]){
                            d[i%2][j][k] = jobb(d[i%2][j][k],d[(i+1)%2][j][k]);
                            jo[i%2][j][k] = true;
                        }
                    } else if(s[i][j]=='('){
                        if(j!=0 && jo[(i+1)%2][j-1][k]){
                            h = d[(i+1)%2][j-1][k]+'(';
                            d[i%2][j][k+1] = jobb(d[i%2][j][k+1],h);
                            jo[i%2][j][k+1] = true;
                        }
                        if(j!=M-1 && jo[(i+1)%2][j+1][k]){
                            h = d[(i+1)%2][j+1][k]+'(';
                            d[i%2][j][k+1] = jobb(d[i%2][j][k+1],h);
                            jo[i%2][j][k+1] = true;
                        }
                        if(jo[(i+1)%2][j][k]){
                            h = d[(i+1)%2][j][k]+'(';
                            d[i%2][j][k+1] = jobb(d[i%2][j][k+1],h);
                            jo[i%2][j][k+1] = true;
                        }
                    } else {
                        if(j!=0 && jo[(i+1)%2][j-1][k+1]){
                            h = d[(i+1)%2][j-1][k+1]+')';
                            d[i%2][j][k] = jobb(d[i%2][j][k],h);
                            jo[i%2][j][k] = true;
                        }
                        if(j!=M-1 && jo[(i+1)%2][j+1][k+1]){
                            h = d[(i+1)%2][j+1][k+1]+')';
                            d[i%2][j][k] = jobb(d[i%2][j][k],h);
                            jo[i%2][j][k] = true;
                        }
                        if(jo[(i+1)%2][j][k+1]){
                            h = d[(i+1)%2][j][k+1]+')';
                            d[i%2][j][k] = jobb(d[i%2][j][k],h);
                            jo[i%2][j][k] = true;
                        }
                    }
                }
            }
        }
        for(int j=0; j<M; j++){
            if(jo[i%2][j][0]){
                meg = jobb(meg,d[i%2][j][0]);
            }
        }
    }
    cout << meg.size() << endl;
    cout << meg << endl;
    return 0;
}
