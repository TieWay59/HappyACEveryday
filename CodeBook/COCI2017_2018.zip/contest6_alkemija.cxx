#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <string>
#include <time.h>
#include <stack>
#include <queue>
#include <random>
#include <fstream>
#define endl '\n'
#define flush fflush(stdout), cout.flush()
#define fast ios::sync_with_stdio(0), cin.tie(0), cout.tie(0)
#define debug cout << "ok" << endl
#define finish(x) return cout << x << endl, 0
typedef long long ll;
typedef long double ldb;
const int md = 1e9 + 7, inf = 1e9;
const ll hs = 199;
const ldb eps = 1e-9, pi = acos(-1);
using namespace std;

int n, m, k, l, r;
set<int> a;
vector<vector<int>> has;
vector<vector<int>> gives;
vector<int> sizes;

int main() {
	fast;
	cin >> n >> m;
	has.resize(n);
	for (int i = 0, x; i < m; i++) {
		cin >> x;
		a.insert(x - 1);
	}
	cin >> k;
	gives.resize(k);
	sizes.resize(k);
	for (int i = 0, tmp; i < k; i++) {
		cin >> l >> r;
		sizes[i] = l;
		while (l--) {
			cin >> tmp;
			has[tmp - 1].push_back(i);
		}
		gives[i].reserve(r);
		while (r--) {
			cin >> tmp;
			gives[i].push_back(tmp - 1);
		}
	}

	queue<int> q;
	for (const auto &i : a) {
		for (const auto &j : has[i]) {
			if (--sizes[j] == 0) q.push(j);
		}
	}
	
	while (!q.empty()) {
		int x = q.front(); q.pop();
		for (const auto &i : gives[x]) {
			if (a.find(i) == a.end()) {
				a.insert(i);
				for (const auto &j : has[i]) {
					if (--sizes[j] == 0) q.push(j);
				}
			}
		}
	}

	cout << a.size() << endl;
	for (const auto &i : a) cout << i + 1 << " "; cout << endl;
}