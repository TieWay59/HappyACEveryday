#include <fstream>
#include <cmath>
#include <vector>
#include <string>
#include <algorithm>
#include <cstring>
#include <map>
#include <queue>
#include <bitset>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <set>
#include <complex>
#include <cstring>

using namespace std;

const int SIZE = 1 << 10;

int pointer = SIZE;
char buffer[SIZE];

char Advance() {
    if (pointer == SIZE) {
        fread(buffer, 1, SIZE, stdin);
        pointer = 0;
    }
    return buffer[pointer++];
}

int Read() {
    int answer = 0;
    char ch = Advance();
    while (!isdigit(ch))
        ch = Advance();
    while (isdigit(ch)) {
        answer = answer * 10 + ch - '0';
        ch = Advance();
    }
    return answer;
}

const int MAXN = 100;
const int MAXM = 100;
const int MAXT = 100;
const int INF = 1000000000;
const long long INFLL = 1000000000000000000LL;

struct Edge {
    int a;
    int t;
    int c;
};

vector<Edge> g[1 + MAXN];
int best[1 + MAXN][1 + MAXM * MAXT];
priority_queue<pair<int, pair<int, int> > > Heap;

int main() {
    //freopen("tema.in", "r", stdin);
    //freopen("tema.out", "w", stdout);
    int n, m, sum = 0;
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= m; i++) {
        int a, b, t, c;
        scanf("%d%d%d%d", &a, &b, &t, &c);
        g[a].push_back({b, t, c});
        g[b].push_back({a, t, c});
        sum += t;
    }
    for (int i = 1; i <= n; i++)
        for (int j = 0; j <= sum; j++)
            best[i][j] = INF;
    best[1][0] = 0;
    Heap.push(make_pair(0, make_pair(1, 0)));
    while (!Heap.empty()) {
        int node = Heap.top().second.first, moment = Heap.top().second.second, cost = -Heap.top().first;
        Heap.pop();
        if (cost != best[node][moment])
            continue;
        for (auto &it : g[node])
            if (moment + it.t <= sum && cost + it.c < best[it.a][moment + it.t]) {
                best[it.a][moment + it.t] = cost + it.c;
                Heap.push(make_pair(-best[it.a][moment + it.t], make_pair(it.a, moment + it.t)));
            }
    }
    for (int i = 2; i <= n; i++) {
        long long answer = INFLL;
        for (int j = 0; j <= sum; j++)
            if (best[i][j] != INF)
                answer = min(answer, 1LL * j * best[i][j]);
        if (answer == INFLL)
            answer = -1;
        printf("%lld\n", answer);
    }
    return 0;
}
