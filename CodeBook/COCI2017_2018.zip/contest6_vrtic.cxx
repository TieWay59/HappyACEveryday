#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <string>
#include <time.h>
#include <stack>
#include <queue>
#include <random>
#include <fstream>
#define endl '\n'
#define flush fflush(stdout), cout.flush()
#define fast ios::sync_with_stdio(0), cin.tie(0), cout.tie(0)
#define debug cout << "ok" << endl
#define finish(x) return cout << x << endl, 0
typedef long long ll;
typedef long double ldb;
const int md = 1e9 + 7, inf = 1e9 + 7;
const ll hs = 199;
const ldb eps = 1e-9, pi = acos(-1);
using namespace std;

int n, p[150], a[150], ans[150][150] = {};
vector<vector<int>> cyc;

void findcyc() {
	int vis[150] = {}, at;
	for (int i = 0; i < n; i++) {
		if (!vis[i]) {
			vis[i] = 1;
			cyc.push_back(vector<int>());
			cyc.back().push_back(i);
			at = p[i];
			while (at != i) {
				vis[at] = 1;
				cyc.back().push_back(at);
				at = p[at];
			}
		}
	}
}

int bs(int row, int val) {
	static int lo, hi, mid;
	lo = row, hi = n - 1;
	while (lo < hi) {
		mid = (lo + hi + 1) / 2;
		if (ans[row][mid] <= val) lo = mid;
		else hi = mid - 1;
	}
	return lo;
}

pair<bool, vector<int>> can(int mx) {
	multimap<int, int> m;
	for (int i = 0; i < cyc.size(); i++)
		m.insert({ cyc[i].size(), i });

	vector<int> rtn;
	int at = 0, bb;
	while (at < n) {
		bb = bs(at, mx);
		auto it = m.upper_bound(bb - at + 1);
		if (it == m.begin()) return{ false, vector<int>() };
		--it;
		rtn.push_back(it->second);
		at += it->first;
		m.erase(it);
	}
	return{ true, rtn };
}

vector<int> best(int st, int en) {
	vector<int> rtn;
	rtn.reserve(en - st + 1);
	rtn.push_back(a[st]);
	if (st == en) return rtn;

	for (int i = st + 2; i <= en; i += 2)
		rtn.push_back(a[i]);

	if ((en - st) & 1) {
		for (int i = en; i >= st; i -= 2)
			rtn.push_back(a[i]);
	}
	else {
		for (int i = en - 1; i >= st; i -= 2)
			rtn.push_back(a[i]);
	}
	return rtn;
}

int main() {
	fast;
	cin >> n;
	for (int i = 0; i < n; i++) cin >> p[i], --p[i];
	for (int i = 0; i < n; i++) cin >> a[i];
	sort(a, a + n);

	ans[n - 1][n - 1] = 0;
	for (int i = 0, mx; i < n - 1; i++) {
		ans[i][i] = 0;
		ans[i][i + 1] = a[i + 1] - a[i];
		for (int j = i + 2; j < n; j += 2) { // odd length
			mx = max(a[i + 1] - a[i], a[j] - a[j - 1]);
			for (int x = i + 2; x <= j; x += 2)
				mx = max(mx, a[x] - a[x - 2]);
			for (int x = j - 3; x >= i; x -= 2)
				mx = max(mx, a[x + 2] - a[x]);
			ans[i][j] = mx;
		}
		for (int j = i + 3; j < n; j += 2) { // even length
			mx = max(a[i + 1] - a[i], a[j] - a[j - 1]);
			for (int x = i + 2; x <= j; x += 2)
				mx = max(mx, a[x] - a[x - 2]);
			for (int x = j - 2; x >= i; x -= 2)
				mx = max(mx, a[x + 2] - a[x]);
			ans[i][j] = mx;
		}
	}

	findcyc();

//	cout << endl;
//	for (int i = 0; i < n; i++) {
//		for (int j = 0; j < n; j++) cout << ans[i][j] << " "; cout << endl;
//	}


	int lo = 0, hi = inf, mid;
	pair<bool, vector<int>> rtn;
	vector<int> ans;
	while (lo < hi) {
		mid = lo + (hi - lo) / 2;
		rtn = can(mid);
		if (rtn.first) {
			hi = mid;
			ans = rtn.second;
		}
		else lo = mid + 1;
	}
	vector<int> output(n);
	vector<int> order;
	for (int i = 0, st = 0; i < ans.size(); i++) {
		order = best(st, st + cyc[ans[i]].size() - 1);
		st += cyc[ans[i]].size();
		for (const auto &j : cyc[ans[i]]) {
			output[j] = order.back();
			order.pop_back();
		}
	}
	cout << lo << endl;
	for (const auto &i : output) cout << i << " "; cout << endl;
}