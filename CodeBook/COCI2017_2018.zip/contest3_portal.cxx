#include <iostream>
#include <set>

using namespace std;

int N, M, a1, b1, a2, b2, a, b, c, tart, megy;
int t[500][500][4];
int mini[500][500];
int d[500][500];
int fia[250010][2];
bool volt[500][500];
bool v[500][500];
string s[500];
set<pair<int,pair<int,int> > > szet;
pair<int,pair<int,int> > ki;

void ok(int x, int y){
    if(x>=0 && x<N && y>=0 && y<M){
        if(!v[x][y]){
            v[x][y] = true;
            mini[x][y] = c+1;
            fia[megy][0] = x;
            fia[megy][1] = y;
            megy++;
        }
    }
}
void be(int x, int y, int z){
    if(x>=0 && x<N && y>=0 && y<M){
        if((!volt[x][y]) && s[x][y]!='#'){
            if(d[x][y]>z){
                szet.erase({d[x][y],{x,y}});
                d[x][y] = z;
                szet.insert({d[x][y],{x,y}});
            }
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin >> N >> M;
    for(int i=0; i<N; i++){
        cin >> s[i];
    }
    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            if(s[i][j]=='#'){
                t[i][j][3] = j+1;
            } else {
                t[i][j][3] = t[i][j-1][3];
            }
            if(s[i][M-1-j]=='#'){
                t[i][M-1-j][1] = M-1-j-1;
            } else {
                t[i][M-1-j][1] = t[i][M-j][1];
            }
            mini[i][j] = 1000000000;
            if(s[i][j]=='C'){
                a1 = i; b1 = j;
            }
            if(s[i][j]=='F'){
                a2 = i; b2 = j;
            }
            d[i][j] = 1000000000;
            if(s[i][j]=='#'){
                fia[megy][0] = i;
                fia[megy][1] = j;
                mini[i][j] = -1;
                v[i][j] = true;
                megy++;
            }
        }
    }
    for(int j=0; j<M; j++){
        for(int i=0; i<N; i++){
            if(s[i][j]=='#'){
                t[i][j][0] = i+1;
            } else {
                t[i][j][0] = t[i-1][j][0];
            }
            if(s[N-1-i][j]=='#'){
                t[N-1-i][j][2] = N-1-i-1;
            } else {
                t[N-1-i][j][2] = t[N-i][j][2];
            }
        }
    }
    while(tart<megy){
        a = fia[tart][0];
        b = fia[tart][1];
        c = mini[a][b];
        ok(a-1,b);
        ok(a+1,b);
        ok(a,b-1);
        ok(a,b+1);
        tart++;
    }
    szet.insert({0,{a1,b1}});
    while((!szet.empty()) && (!volt[a2][b2])){
        ki = *szet.begin();
        szet.erase(szet.begin());
        a = ki.second.first;
        b = ki.second.second;
        c = ki.first;
        volt[a][b] = true;
        be(a+1,b,c+1);
        be(a-1,b,c+1);
        be(a,b-1,c+1);
        be(a,b+1,c+1);
        be(t[a][b][0],b,mini[a][b]+1+c);
        be(a,t[a][b][1],mini[a][b]+1+c);
        be(t[a][b][2],b,mini[a][b]+1+c);
        be(a,t[a][b][3],mini[a][b]+1+c);
    }
    if(d[a2][b2]==1000000000){
        cout << "nemoguce" << endl;
    } else {
        cout << d[a2][b2] << endl;
    }
    return 0;
}
