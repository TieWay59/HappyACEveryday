#include <iostream>
#include <algorithm>

using namespace std;

int N;
int a[100];
int b[100];
bool jo;

int main()
{
    ios_base::sync_with_stdio(false);
    cin >> N;
    for(int i=0; i<N; i++) cin >> a[i];
    for(int i=0; i<N; i++) cin >> b[i];
    sort(a,a+N);
    sort(b,b+N);
    jo = true;
    for(int i=0; i<N; i++){
        if(a[i]>b[i]) jo = false;
    }
    if(jo){
        cout << "DA" << endl;
    } else {
        cout << "NE" << endl;
    }
    return 0;
}
