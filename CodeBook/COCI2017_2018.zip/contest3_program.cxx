#include <iostream>

using namespace std;

string s;
int t[26][50010];
int Q, a, b, c, d;
bool jo;

int main()
{
    ios_base::sync_with_stdio(false);
    cin >> s;
    for(int i=1; i<=s.length(); i++){
         for(int j=0; j<26; j++){
            t[j][i] = t[j][i-1];
         }
         t[s[i-1]-'a'][i]++;
    }
    cin >> Q;
    for(int i=0; i<Q; i++){
        cin >> a >> b >> c >> d;
        jo = true;
        for(int j=0; j<26; j++){
            if(t[j][b]-t[j][a-1]!=t[j][d]-t[j][c-1]) jo = false;
        }
        if(jo){
            cout << "DA" << endl;
        } else {
            cout << "NE" << endl;
        }
    }
    return 0;
}
