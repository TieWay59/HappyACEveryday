#include <fstream>
#include <cmath>
#include <vector>
#include <string>
#include <algorithm>
#include <cstring>
#include <map>
#include <queue>
#include <bitset>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <set>
#include <complex>
#include <cstring>

using namespace std;

const int SIZE = 1 << 10;

int pointer = SIZE;
char buffer[SIZE];

char Advance() {
    if (pointer == SIZE) {
        fread(buffer, 1, SIZE, stdin);
        pointer = 0;
    }
    return buffer[pointer++];
}

int Read() {
    int answer = 0;
    char ch = Advance();
    while (!isdigit(ch))
        ch = Advance();
    while (isdigit(ch)) {
        answer = answer * 10 + ch - '0';
        ch = Advance();
    }
    return answer;
}

const int MAXN = 1000;

int v[1 + MAXN];

int Add(int x, int k) {
    if (x % (2 * k + 1) == 0)
        return x / (2 * k + 1);
    return x / (2 * k + 1) + 1;
}

int main() {
    //freopen("tema.in", "r", stdin);
    //freopen("tema.out", "w", stdout);
    int n, m, k, answer = 0;
    scanf("%d%d%d", &n, &m, &k);
    for (int i = 1; i <= m; i++)
        scanf("%d", &v[i]);
    if (v[1] - k > 1)
        answer += Add(v[1] - k - 1, k);
    if (v[m] + k < n)
        answer += Add(n - (v[m] + k), k);
    for (int i = 1; i < n; i++)
        if (v[i] + k < v[i + 1] - k)
            answer += Add(v[i + 1] - k - (v[i] + k) - 1, k);
    printf("%d\n", answer);
    return 0;
}
