#include <iostream>
#include <vector>

using namespace std;

int N, M, a, b;
vector<int> el[10000];
bool volt[5000];
int par[10000];
bool van[5000];
bool ok[5000];
bool p;

bool be(int x){
    if(volt[x]) return (false);
    volt[x] = true;
    for(int j:el[x]){
        if(par[j]==-1 || be(par[j])){
            par[j] = x;
            return (true);
        }
    }
    return (false);
}
void ki(int x){
    if(volt[x]) return;
    volt[x] = true;
    ok[x] = true;
    for(int j:el[x]){
        ki(par[j]);
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin >> N >> M;
    for(int i=0; i<M; i++){
        cin >> a >> b;
        a--; b += N-1;
        el[a].push_back(b);
        el[b].push_back(a);
    }
    for(int i=N; i<2*N; i++){
        par[i] = -1;
    }
    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            volt[j] = false;
        }
        p = be(i);
    }
    for(int i=N; i<2*N; i++){
        if(par[i]!=-1){
            van[par[i]] = true;
        }
    }
    for(int i=0; i<N; i++){
        volt[i] = false;
    }
    for(int i=0; i<N; i++){
        if(!van[i]) ki(i);
    }
    for(int i=0; i<N; i++){
        if(ok[i]){
            cout << "Mirko" << endl;
        } else {
            cout << "Slavko" << endl;
        }
    }
    return 0;
}
