#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <string>
#include <time.h>
#include <stack>
#include <queue>
#include <random>
#include <fstream>
#define endl '\n'
#define flush fflush(stdout), cout.flush()
#define fast ios::sync_with_stdio(0), cin.tie(0), cout.tie(0)
#define debug cout << "ok" << endl
#define finish(x) return cout << x << endl, 0
typedef long long ll;
typedef long double ldb;
const int md = 1e9 + 7, inf = 1e9 + 7;
const ll hs = 199;
const ldb eps = 1e-9, pi = acos(-1);
using namespace std;

unsigned long long c, d, b, m, pw[100];
vector<unsigned long long> sum[35005];

int logb(unsigned long long x) {
	int rtn = -1;
	while (x) {
		rtn++;
		x /= b;
	}
	return rtn;
}

int digsum(unsigned long long x) {
	int at = logb(x), rtn = 0;
	for (; at >= 0; at--) {
		rtn += (x / pw[at]);
		x -= (x / pw[at] * pw[at]);
	}
	return rtn;
}

int main() {
	fast;
	cin >> c >> d >> b >> m;
	pw[0] = 1;
	for (int i = 1; i < 100; i++) pw[i] = b * pw[i - 1];

	if (b <= 100) {
		int ds;
		for (unsigned long long i = 1;; i++) {
			ds = digsum(c * i + d);
			sum[ds].push_back(i);
			if (sum[ds].size() == m) {
				for (const auto &i : sum[ds]) cout << i << " "; cout << endl;
				return 0;
			}
		}
	}
	else {
		int ds;
		for (int x = 1; x <= b; x++) {
			for (unsigned long long i = x; i <= (unsigned long long)1000000000000000; i += b) {
				ds = digsum(c * i + d);
				sum[ds].push_back(i);
				if (sum[ds].size() == m) {
					for (const auto &i : sum[ds]) cout << i << " "; cout << endl;
					return 0;
				}
			}
		}
	}
}