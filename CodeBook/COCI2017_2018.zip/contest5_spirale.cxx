#include <iostream>

using namespace std;

int N, M, K, a, b, c, o, tart, h;
int mini[500][500];

void ok(){
    if(a-200>=0 && a-200<N && b-200>=0 && b-200<M){
        mini[a][b] = min(mini[a][b],tart);
        o--;
    }
    tart++;
}

int main()
{
    ios_base::sync_with_stdio(false);
    for(int i=0; i<500; i++){
        for(int j=0; j<500; j++) mini[i][j] = 1000000000;
    }
    cin >> N >> M >> K;
    for(int i=0; i<K; i++){
        cin >> a >> b >> c;
        a += 199;
        b += 199;
        mini[a][b] = 1;
        o = N*M-1; tart = 2; h = 0;
        if(c==0){
            while(o>0){
                a--; h += 2;
                b--;
                for(int j=0; j<h; j++){
                    b++;
                    ok();
                }
                for(int j=0; j<h; j++){
                    a++;
                    ok();
                }
                for(int j=0; j<h; j++){
                    b--;
                    ok();
                }
                for(int j=0; j<h; j++){
                    a--;
                    ok();
                }
            }
        } else {
            while(o>0){
                a--; h += 2;
                b++;
                for(int j=0; j<h; j++){
                    b--;
                    ok();
                }
                for(int j=0; j<h; j++){
                    a++;
                    ok();
                }
                for(int j=0; j<h; j++){
                    b++;
                    ok();
                }
                for(int j=0; j<h; j++){
                    a--;
                    ok();
                }
            }
        }
    }
    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            cout << mini[i+200][j+200] << ' ';
        }
        cout << endl;
    }
    return 0;
}
