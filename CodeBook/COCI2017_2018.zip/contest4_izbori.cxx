#include <bits/stdc++.h>
#define F first
#define S second
#define pii pair<int, int>
#define pb push_back

using namespace std;

typedef long long ll;
typedef long double ld;

const int N = 1e2 + 10, M = 16;

int a[N][M], sc[M];
bool is[M];

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0);
    int n, m, k; cin >> n >> m >> k;
    --k;
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++){
            cin >> a[i][j];
            a[i][j] --;
        }
        sc[a[i][0]] ++;
    }
    int mx = -1, id = -1;
    for(int i=m-1; i>=0; i--){
        if(sc[i] >= mx){
            mx = sc[i];
            id = i;
        }
    }

    cout << id + 1 << endl;

    int ans = -1;

    for(int mask=0; mask < (1 << m); mask++)
    {
        memset(is, 0, sizeof is);
        memset(sc, 0, sizeof sc);
        int cnt = 0;

        if(mask == 0)continue;
        for(int j=0; j<m; j++)
            if(mask & (1 << j))is[j] = true, cnt ++;
        for(int i=0; i<n; i++)
            for(int j=0; j<m; j++)
                if(is[a[i][j]]){
                    sc[a[i][j]]++; break;
                }
        int mx = -1, id = -1;
        for(int j=m-1; j>=0; j--)
            if(sc[j] >= mx)mx = sc[j], id = j;
        if(id == k)ans = max(ans, cnt);
    }
    cout << m - ans << endl;
}
