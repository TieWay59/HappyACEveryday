#include <iostream>
#include <vector>

using namespace std;

long long N, a;
long long db[200000];
long long o[200000];
vector<int> el[200000];

void be(int x){
    db[x] = 1;
    for(int i:el[x]){
        be(i);
        db[x] += db[i];
        o[x] += o[i];
    }
    o[x] += db[x];
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin >> N;
    for(int i=1; i<N; i++){
        cin >> a;
        el[a-1].push_back(i);
    }
    be(0);
    for(int i=0; i<N; i++){
        cout << o[i] << ' ';
    }
    return 0;
}
