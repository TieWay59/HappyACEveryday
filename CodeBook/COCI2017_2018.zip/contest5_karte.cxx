#include <iostream>

using namespace std;

int N, K, a, o, b, kell, megy;
int db[500001];
int meg[500001];

int main()
{
    ios_base::sync_with_stdio(false);
    cin >> N >> K;
    for(int i=0; i<N; i++){
        cin >> a;
        db[a]++;
        if(a>K) o++;
    }
    if(o>K){
        cout << -1 << endl;
    } else {
        a = 0;
        kell = K-o;
        while(kell>0 && a!=K+1){
            while(kell>0 && db[a]>0){
                meg[megy] = a;
                megy++;
                if(b<a){
                    b++;
                    kell--;
                }
                db[a]--;
            }
            if(kell>0) a++;
        }
        if(kell>0){
            cout << -1 << endl;
        } else {
            for(int i=K; i>=a; i--){
                for(int j=0; j<db[i]; j++){
                    cout << i << ' ';
                }
            }
            for(int i=500000; i>=K+1; i--){
                for(int j=0; j<db[i]; j++){
                    cout << i << ' ';
                }
            }
            for(int i=megy-1; i>=0; i--){
                cout << meg[i] << ' ';
            }
            cout << endl;
        }
    }
    return 0;
}
