#include <fstream>
#include <cmath>
#include <vector>
#include <string>
#include <algorithm>
#include <cstring>
#include <map>
#include <queue>
#include <bitset>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <set>
#include <complex>
#include <cstring>

using namespace std;

const int SIZE = 1 << 10;

int pointer = SIZE;
char buffer[SIZE];

char Advance() {
    if (pointer == SIZE) {
        fread(buffer, 1, SIZE, stdin);
        pointer = 0;
    }
    return buffer[pointer++];
}

int Read() {
    int answer = 0;
    char ch = Advance();
    while (!isdigit(ch))
        ch = Advance();
    while (isdigit(ch)) {
        answer = answer * 10 + ch - '0';
        ch = Advance();
    }
    return answer;
}

const int MOD = 1000000007;
const int MAXN = 1000000;

int line[1 + MAXN], column[1 + MAXN];
vector<int> deltaLine, deltaColumn;

void Add(int &x, int y) {
    x += y;
    if (x >= MOD)
        x -= MOD;
}

void Subtract(int &x, int y) {
    x -= y;
    if (x < 0)
        x += MOD;
}

int Line(int i, int n, int m) {
    return (1LL * (i - 1) * m * m + 1LL * m * (m + 1) / 2) % MOD;
}

int Column(int j, int n, int m) {
    return (1LL * m * (n - 1) * n / 2 + 1LL * j * n) % MOD;
}

int Cell(int i, int j, int n, int m) {
    return (1LL * (i - 1) * m + j) % MOD;
}

int main() {
    //freopen("tema.in", "r", stdin);
    //freopen("tema.out", "w", stdout);
    int n, m, k;
    scanf("%d%d%d\n", &n, &m, &k);
    int answer = (1LL * m * n) % MOD;
    answer = (1LL * answer * (answer + 1) / 2) % MOD;
    for (int i = 1; i <= n; i++)
        line[i] = 1;
    for (int j = 1; j <= m; j++)
        column[j] = 1;
    for (int i = 1; i <= k; i++) {
        char type;
        int a, b;
        scanf("%c%d%d\n", &type, &a, &b);
        if (type == 'R')
            line[a] = (1LL * line[a] * b) % MOD;
        if (type == 'S')
            column[a] = (1LL * column[a] * b) % MOD;
    }
    for (int i = 1; i <= n; i++)
        if (line[i] != 1) {
            int x = Line(i, n, m);
            Subtract(answer, x);
            Add(answer, (1LL * x * line[i]) % MOD);
            deltaLine.push_back(i);
        }
    for (int j = 1; j <= m; j++)
        if (column[j] != 1) {
            int y = Column(j, n, m);
            Subtract(answer, y);
            Add(answer, (1LL * y * column[j]) % MOD);
            deltaColumn.push_back(j);
        }
    for (auto &it : deltaLine)
        for (auto &jt : deltaColumn) {
            int z = Cell(it, jt, n, m);
            Subtract(answer, (1LL * line[it] * z) % MOD);
            Subtract(answer, (1LL * column[jt] * z) % MOD);
            int k = (1LL * line[it] * column[jt] + 1) % MOD;
            Add(answer, (1LL * k * z) % MOD);
        }
    printf("%d\n", answer);
    return 0;
}
