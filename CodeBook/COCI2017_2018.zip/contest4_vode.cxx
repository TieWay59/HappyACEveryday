#include <bits/stdc++.h>
using namespace std;
typedef long long lint;
const int MAXN = 5005;
const int mod = 1e9 + 7;
typedef pair<int, int> pi;

int dp[MAXN][MAXN], a[MAXN];
int sum[2][MAXN][MAXN];

int main(){
	int n, m, k;
	cin >> n >> m >> k;
	for(int i=0; i<n; i++) cin >> a[i];
	for(int i=m-1; i>=0; i--){
		for(int j=0; j<n; j++){
			if(a[j] == a[(j+1)%n]){
				dp[i][j] = (sum[1][i+1][(j+1)%n] - sum[1][min(m, i+k+1)][(j+1)%n] > 0);
			}
			else{
				dp[i][j] = (sum[0][i+1][(j+1)%n] - sum[0][min(m, i+k+1)][(j+1)%n] > 0);
			}
			sum[0][i][j] = sum[0][i+1][j] + (dp[i][j] == 0);
			sum[1][i][j] = sum[1][i+1][j] + (dp[i][j] == 1);
		}
	}
	for(int i=0; i<n; i++) printf("%d ", a[i] == dp[0][i]);
}
