#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define f(i, x, n) for(int i = x; i < (int)(n); ++i)

int const N = 100 + 100 + 100 + 2, M = N * N;
int E, Pa[N], VIS[N], VS, SR, TR;
vector<int> G[N];
pair<int, int> Ed[M];

bool path(int v = SR){
	if (v == TR)return true;
	VIS[v] = VS;
	f(i, 0, G[v].size()){
		pair<int, int> &e = Ed[G[v][i]];
		if (e.second == 0)continue;
		if (VIS[e.first] != VS && path(e.first)) { Pa[e.first] = G[v][i]; return true; }
	}
	return false;
}

int fix(){
	int an = 2e9, v = TR;
	while (v != SR){
		int e = Pa[v];
		an = min(an, Ed[e].second);
		v = Ed[e ^ 1].first;
	}
	v = TR;
	while (v != SR){
		int e = Pa[v];
		Ed[e].second -= an;
		Ed[e ^ 1].second += an;
		v = Ed[e ^ 1].first;
	}
	return an;
}

inline int MF(int a, int b){
	SR = a, TR = b;
	int an = 0;
	++VS;
	while (path())an += fix(), ++VS;
	return an;
}

inline void aded(int a, int b, int w1 = 1, int w2 = 0){
	Ed[E] = make_pair(b, w1);
	Ed[E + 1] = make_pair(a, w2);
	G[a].push_back(E++);
	G[b].push_back(E++);
}

inline void CL(){
	E = 0;
	f(i, 0, N)G[i].clear();
}

struct P{
	int x, y;
	P(){}
	void sc() { scanf("%d%d", &x, &y); }
	int ds(P o){
		int dx = x - o.x, dy = y - o.y;
		return dx * dx + dy * dy;
	}
}st[100], bst[100];

vector<int> bs[100];
int n, m, c, k, sr, sn;

void bld(int d){
	f(i, 0, n)aded(sr, i);
	f(i, 0, n)f(j, 0, m)if (st[i].ds(bst[j]) <= d)aded(i, j + n);
	f(i, 0, k)f(j, 0, bs[i].size())aded(bs[i][j] + n, i + n + m, 1e9);
	f(i, 0, k)aded(i + n + m, sn, c);
}

int main(){
	scanf("%d%d%d%d", &n, &m, &c, &k);
	f(i, 0, n)st[i].sc();
	f(i, 0, m)bst[i].sc();
	f(i, 0, k){
		int sz;
		scanf("%d", &sz);
		bs[i].resize(sz);
		f(j, 0, sz)scanf("%d", &bs[i][j]), --bs[i][j];
	}
	sr = n + m + k, sn = sr + 1;
	int l = 0, r = 1e9;
	while (r > l){
		int m = l + r >> 1;
		CL();
		bld(m);
		if (MF(sr, sn) == n)r = m;
		else l = m + 1;
	}
	CL();
	bld(l);
	if (MF(sr, sn) < n) { printf("-1\n"); return 0; }
	printf("%d\n", l);
	f(i, 0, n)f(j, 0, G[i].size()){
		pair<int, int> &e = Ed[G[i][j]];
		if (e.second == 0) { printf("%d\n", e.first - n + 1); break; }
	}
}