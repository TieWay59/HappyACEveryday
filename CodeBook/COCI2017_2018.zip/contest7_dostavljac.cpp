#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define f(i, x, n) for(int i = x; i < (int)(n); ++i)

int const N = 500;
vector<int> tr[N + 1];
int x[N + 1], n, m, dp[N + 1][N + 1][2];

inline void up(int &x, int y) { x = max(x, y); }

int go(int v = 1, int p = 0){
	dp[v][0][0] = dp[v][0][1] = 0;
	dp[v][1][0] = dp[v][1][1] = x[v];
	int s = 1;
	f(i, 0, tr[v].size()){
		int u = tr[v][i];
		if (u == p)continue;
		int sz = go(u, v);
		int nsz = min(m, s + sz + 2);
		for (int j = s; j >= 0; --j)f(k, 0, sz + 1){
			int csz = j + k + 1;
			if (csz > nsz)break;
			up(dp[v][csz][1], dp[v][j][0] + dp[u][k][1]);
			++csz;
			if (csz > nsz)break;
			up(dp[v][csz][0], dp[v][j][0] + dp[u][k][0]);
			up(dp[v][csz][1], dp[v][j][1] + dp[u][k][0]);
		}
		s = nsz;
	}
	return s;
}

int main(){
	scanf("%d%d", &n, &m);
	f(i, 1, n + 1)scanf("%d", x + i);
	f(i, 1, n){
		int a, b;
		scanf("%d%d", &a, &b);
		tr[a].push_back(b);
		tr[b].push_back(a);
	}
	go();
	int an = 0;
	f(i, 0, m + 1)up(an, dp[1][i][1]);
	printf("%d\n", an);
}