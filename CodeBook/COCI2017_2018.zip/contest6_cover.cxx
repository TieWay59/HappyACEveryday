#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <string>
#include <time.h>
#include <stack>
#include <queue>
#include <random>
#include <fstream>
#define endl '\n'
#define flush fflush(stdout), cout.flush()
#define fast ios::sync_with_stdio(0), cin.tie(0), cout.tie(0)
#define debug cout << "ok" << endl
#define finish(x) return cout << x << endl, 0
typedef long long ll;
typedef long double ldb;
const int md = 1e9 + 7, inf = 1e9;
const ll hs = 199;
const ldb eps = 1e-9, pi = acos(-1);
using namespace std;

int n, nn;
map<int, int> m;
vector<ll> dp;

int main() {
	fast;
	cin >> n;
	for (int i = 0, x, y; i < n; i++) {
		cin >> x >> y;
		x = abs(x), y = abs(y);
		if (!m.count(x) || m[x] < y) m[x] = y;
	}
	vector<pair<int, int>> a;
	for (const auto &i : m) {
		while (a.size() && a.back().second <= i.second) a.pop_back();
		a.push_back(i);
	}
	
	nn = a.size();
	dp.resize(nn);
	dp[0] = 4LL * a[0].first * a[0].second;
	for (int i = 1; i < nn; i++) {
		dp[i] = 4LL * a[i].first * a[0].second;
		for (int j = i; j > 0; j--)
			dp[i] = min(dp[i], 4LL * a[i].first * a[j].second + dp[j - 1]);
	}
	cout << dp.back() << endl;
}