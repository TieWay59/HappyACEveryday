#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <string>
#include <time.h>
#include <stack>
#include <queue>
#include <random>
#include <fstream>
#define endl '\n'
#define flush fflush(stdout), cout.flush()
#define fast ios::sync_with_stdio(0), cin.tie(0), cout.tie(0)
#define debug cout << "ok" << endl
#define finish(x) return cout << x << endl, 0
typedef long long ll;
typedef long double ldb;
const int md = 1e9 + 7, inf = 1e9 + 7;
const ll hs = 199;
const ldb eps = 1e-9, pi = acos(-1);
using namespace std;

string s;
int n, q, suf[26][2000], ncr[2001][2001];
vector<int> loc[26];

int ff(const string &x) {
	return 26 * (x[0] - 'a') + (x[1] - 'a');
}

void work() {
	for (int i = 0; i < 2001; i++) ncr[i][0] = 1;
	for (int j = 1; j < 2001; j++) {
		for (int i = j; i < 2001; i++) {
			if (i == j) ncr[i][j] = 1;
			else ncr[i][j] = (ncr[i - 1][j - 1] + ncr[i - 1][j]) % md;
		}
	}

	for (int i = 0; i < 26; i++) {
		if (int(s.back() - 'a') == i) suf[i][n - 1] = 1;
		else suf[i][n - 1] = 0;
		for (int j = n - 2; j >= 0; j--)
			suf[i][j] = suf[i][j + 1] + (int(s[j] - 'a') == i ? 1 : 0);
	}

	for (int i = 0; i < n - 1; i++) loc[s[i] - 'a'].push_back(i);
}

int calc(int abc, int def) {
	if (abc < def) return 0;
	return ncr[abc][def];
}

map<int, int> was;

int main() {
	fast;
	cin >> s;
	n = s.size();
	work();

	cin >> q;
	string tmp;
	int len;
	ll ans;
	for (int i = 0; i < q; i++) {
		cin >> len >> tmp;
		len -= 2;
		ans = 0;
		if (was.count(676 * len + ff(tmp))) cout << was[676 * len + ff(tmp)] << endl;
		else {
			for (const auto &j : loc[tmp[0] - 'a'])
				if (j >= len)
					ans = (ans + (ll)calc(j, len) * suf[tmp[1] - 'a'][j + 1]) % md;
			cout << ans << endl;
		}
	}
}