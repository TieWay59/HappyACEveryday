#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define f(i, x, n) for(int i = x; i < (int)(n); ++i)

int const N = 200000;
int an[N];

int main(){
	int n, k, m;
	scanf("%d%d%d", &n, &k, &m);
	int ln = n + n - 2;
	int j = m / ((ll)k * ln);
	m -= j * k * ln;
	an[0] = an[n - 1] = j * k;
	f(i, 1, n - 1)an[i] = j * k << 1;
	f(i, 0, n){
		int t = min(m, k);
		an[i] += t;
		m -= t;
	}
	for (int i = n - 2; i > 0; --i){
		int t = min(m, k);
		an[i] += t;
		m -= t;
	}
	printf("%d", an[0]);
	f(i, 1, n)printf(" %d", an[i]);
	printf("\n");
}
