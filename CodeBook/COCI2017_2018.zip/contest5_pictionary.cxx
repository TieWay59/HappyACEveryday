#include <iostream>
#include <vector>

using namespace std;

struct pont{
    int a, b, e;
    pont* bal;
    pont* jobb;
};
pont* fa;
int N, M, Q, a1, b1, tart, a2, b2;
int apa[100001];
int mini[100001];
int aa[100001];
int bb[100001];
int t[200100];
int hova[200100];
vector<int> el[100001];

int hol(int x){
    if(apa[x]<0) return (x);
    return (apa[x] = hol(apa[x]));
}
void be(int x){
    tart++;
    aa[x] = tart;
    hova[tart] = x;
    for(int i:el[x]) be(i);
    tart++;
    bb[x] = tart;
    t[aa[x]] = tart;
}
pont* epit(int x, int y){
    pont* p = new pont;
    pont* bf = NULL;
    pont* jf = NULL;
    p->a = x;
    p->b = y;
    if(x==y){
        p->e = t[x];
    } else {
        bf = epit(x,(x+y)/2);
        jf = epit((x+y)/2+1,y);
        p->e = max(bf->e,jf->e);
    }
    p->bal = bf;
    p->jobb = jf;
    return (p);
}
int ker(pont* f){
    if(f->e<b2) return (-1);
    if(f->a==f->b) return (f->a);
    if((f->a+f->b)/2>=a2) return(ker(f->bal));
    if(f->b<=a2){
        if((f->jobb)->e>=b2) return (ker(f->jobb));
        return (ker(f->bal));
    }
    int mi = ker(f->jobb);
    if(mi!=-1) return (mi);
    return (ker(f->bal));
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin >> N >> M >> Q;
    for(int i=0; i<=N; i++){
        apa[i] = -1;
        mini[i] = i;
    }
    for(int i=M; i>=1; i--){
        for(int j=2*i; j<=N; j+=i){
            a1 = hol(i);
            b1 = hol(j);
            if(a1!=b1){
                el[i].push_back(mini[b1]);
                if(apa[a1]<apa[b1]){
                    apa[b1] = a1;
                } else if(apa[b1]<apa[a1]){
                    apa[a1] = b1;
                    mini[b1] = i;
                } else {
                    apa[a1] = b1;
                    apa[b1]--;
                    mini[b1] = i;
                }
            }
        }
    }
    be(1);
    fa = epit(1,tart);
    for(int i=0; i<Q; i++){
        cin >> a1 >> b1;
        a2 = min(aa[a1],aa[b1]);
        b2 = max(bb[a1],bb[b1]);
        cout << M+1-hova[ker(fa)] << endl;
    }
    return 0;
}
